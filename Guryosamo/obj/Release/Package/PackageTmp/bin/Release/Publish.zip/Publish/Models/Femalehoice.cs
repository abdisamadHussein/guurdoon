﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Guryosamo.Models
{
    public class Femalehoice
    {
        public int id { get; set; }
        public string ageRange { get; set; }
        public string height { get; set; }
        public string weight { get; set; }
        public string skinColor { get; set; }
        public string mariageStatus { get; set; }
        public string education { get; set; }
        public string homeworkkHelp { get; set; }
   



    }
}