﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Guryosamo.Adminstraation.Matching
{
    public class MaleModel
    {
    }
}