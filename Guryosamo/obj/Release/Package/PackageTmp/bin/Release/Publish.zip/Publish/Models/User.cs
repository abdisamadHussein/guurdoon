﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Guryosamo.Models
{
    public class User
    {
        public int id;
        public String first_name;
        public String midlle_name;
        public String last_name;
        public String gender;
        public String phone;
        public String email;
    }
}