﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Guryosamo.Models
{
    public class CompMale
    {

        public string ageRange { get; set; }
        public string mariageStatus { get; set; }
        public string education { get; set; }
        public string height { get; set; }
        public string weight { get; set; }
        public string sckin { get; set; }
        public string cooking { get; set; }
        public string doesSheWork { get; set; }
        public int maleId { get; set; }
        public int femaleId { get; set; }
        public string average { get; set; }

        //CompMale(string ageRange, string mariageStatus, string education, string height, string weight, string sckin, string cooking, string doesSheWork, int maleId)
        //{
        //    this.ageRange = ageRange;
        //    this.mariageStatus = mariageStatus;
        //    this.education = education;
        //    this.height = height;
        //    this.weight = weight;
        //    this.sckin = sckin;
        //    this.cooking = cooking;
        //    this.doesSheWork = doesSheWork;
        //    this.maleId = maleId;

        //}


    }
}