﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Guryosamo.Models
{
    public class MaleInfo
    {
        public String first_name;
        public String midlle_name;
        public String last_name;
        public String fullName;
        public String gender;
        public String age;
        public String mariageStatus;
        public String phone;
        public String email;
        public String address;
    }
}