﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Guryosamo.Models
{
    public class PendingUser
    {
        public String full_name;
        public String email_address;
        public String phone;
        public String service;
        public String Sender_Detail;
       
    }
}